<?php

namespace Modules\PaymentsManager\Entities;

use Illuminate\Database\Eloquent\Model;

class Payments extends Model
{
    protected $fillable = [];
}
