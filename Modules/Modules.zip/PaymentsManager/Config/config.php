<?php

return [
    'name' => 'PaymentsManager'
];
