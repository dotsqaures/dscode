<?php

return [
    'name' => 'ProductManager'
];
