<?php

namespace Modules\AdminUserManager\Entities;

use Illuminate\Database\Eloquent\Model;

class AdminRoleAdminUser extends Model
{
    protected $fillable = [];
    protected $table = 'admin_role_admin_user';
}
