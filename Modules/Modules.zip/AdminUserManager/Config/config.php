<?php

return [
    'name' => 'AdminUserManager'
];
