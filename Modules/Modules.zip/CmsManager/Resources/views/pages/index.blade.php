


<div class="middle-wrapper " style=" padding: 3px 0 0 16px">
        <div class="container">
            <div class="login-logo" style="margin: auto;width: 100px;">
        <img src="http://madogkaffeappen.dk/storage/settings/40jihN8SewgZYloXuVXfWf5Cf7Q2af4ZhlsKPg9N.png" style="max-height:100px;">
    </div>
        <div class="static-page pad-t40 pad-b40">

        <div class="heading">
        <h1>{!! $page->title  !!}</h1>
        </div>

        <div class="inner-mid-part contact-form pad30">


         <p>{!! $page->description  !!}</p>

        </div>
       </div>

       </div>
</div>



