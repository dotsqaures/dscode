<?php

return [
    'name' => 'CategoriesManager'
];
