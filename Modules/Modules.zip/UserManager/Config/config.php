<?php

return [
    'name' => 'UserManager'
];
