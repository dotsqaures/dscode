<?php

return [
    'name' => 'OrdersManager'
];
