<?php

return [
    'name' => 'StampsManager'
];
