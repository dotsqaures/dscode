<?php

return [
    'name' => 'RestaurentsManager'
];
